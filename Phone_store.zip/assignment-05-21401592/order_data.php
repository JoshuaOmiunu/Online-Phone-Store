<?php


require_once 'vendor/autoload.php';
// use App\Models\Customer;
use App\Models\MongoDB;

$connection = new MongoDB;

$orders = $connection->allorders();

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Carphone Warehouse </title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="vendors/feather/feather.css">
  <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="vendors/typicons/typicons.css">
  <link rel="stylesheet" href="vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/vertical-layout-light/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />
</head>

<body>
  <div class="container-scroller">
    
    <div class="container-fluid page-body-wrapper">
      <?php
      include('sidebar.php');
      ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">

            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Order Table</h4>

                  <p class="card-description">
                  </p>
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th>
                            OrderID
                          </th>
                          <th>
                          Customer Name </th>
                          <th>
                          Items Name
                          </th>
                        
                          <th>
                            Action
                          </th>

                        </tr>

                      </thead>
                      <tbody>
                        <?php 
                          foreach($orders as $order){
                        ?>
                        <tr>

                          <td>
                            <?php echo $order['_id'] ?>
                          </td>
                          <td>

                            <?php 
                              $customer = $connection->editcustomer($order['customer']); 
                              echo $customer['firstName'];
                            ?>
                          </td>
                          <td>
                            <?php 
                              foreach($order['items'] as $items){
                                $item = $connection->edititem($items);
                                echo $item['model'];
                                echo '<br>';
                              }
                             ?>
                          </td>
                          <!-- <td>
                            <?php echo $item['price'] ?>
                          </td> -->

                          <td>
                            <form action="delete_order.php" method="post">
                              <input type="hidden" name="id" id="id" value="<?php echo $order['_id'] ?>">
                              <input type="submit" value="Delete" class="btn btn-outline-danger">
                            </form>
                            <form action="edit_order.php" method="post">
                              <input type="hidden" name="id" id="id" value="<?php echo $order['_id'] ?>">
                              <input type="submit" value="Edit" class="btn btn-outline-info">
                            </form>
                          </td> 
                        <?php
                          }
                        ?>

                      </tbody>
                    </table>
                    <div>
                    <a>
                      <button class="btn btn-primary" onclick="location.href='add_order.php'">Add Order</button>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->

        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
 
</body>

</html>