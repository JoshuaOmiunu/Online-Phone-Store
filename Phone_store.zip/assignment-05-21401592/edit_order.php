<?php

require_once 'vendor/autoload.php';
use App\Models\Order;
use App\Models\MongoDB;

$connection = new MongoDB;
$id = $_POST['id'];
$customers = $connection->allcustomers();
$items = $connection->allitems();
$items = iterator_to_array($items);

$order = $connection->editorder($id);

if(isset($_POST['update'])){
  $newcustomer = $_POST['customer'];
  $newitems = $_POST['items'];

  $o = new Order($newcustomer,$newitems);
  

  $result = $connection->updateorder($id,$o);
  // echo "<script>alert('Customer added successfully!');</script>";
  if($result == 1){
    echo "<script>alert('Order updated successfully!');</script>";
  }
  // print_r($c->getTitle());
  $order = $connection->editorder($id);
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Carphone Warehouse </title>
  <!-- plugins:css -->
 <link rel="stylesheet" href="vendors/feather/feather.css">
  <link rel="stylesheet" href="vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="vendors/typicons/typicons.css">
  <link rel="stylesheet" href="vendors/simple-line-icons/css/simple-line-icons.css">
  <link rel="stylesheet" href="vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <link rel="stylesheet" href="vendors/select2/select2.min.css">
  <link rel="stylesheet" href="vendors/select2-bootstrap-theme/select2-bootstrap.min.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="css/vertical-layout-light/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
  <div class="container-scroller">
    <!-- partial:../../partials/_navbar.html -->
    
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:../../partials/_settings-panel.html -->
      <div class="theme-setting-wrapper">
        <div id="settings-trigger"><i class="ti-settings"></i></div>
        <div id="theme-settings" class="settings-panel">
          <i class="settings-close ti-close"></i>
          
          <div class="color-tiles mx-0 px-4">
            <div class="tiles success"></div>
            <div class="tiles warning"></div>
            <div class="tiles danger"></div>
            <div class="tiles info"></div>
            <div class="tiles dark"></div>
            <div class="tiles default"></div>
          </div>
        </div>
      </div>
      <div id="right-sidebar" class="settings-panel">
        <i class="settings-close ti-close"></i>
        <ul class="nav nav-tabs border-top" id="setting-panel" role="tablist">
          <li class="nav-item">
            <a class="nav-link active" id="todo-tab" data-bs-toggle="tab" href="#todo-section" role="tab" aria-controls="todo-section" aria-expanded="true">TO DO LIST</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="chats-tab" data-bs-toggle="tab" href="#chats-section" role="tab" aria-controls="chats-section">CHATS</a>
          </li>
        </ul>
        <div class="tab-content" id="setting-content">
          <div class="tab-pane fade show active scroll-wrapper" id="todo-section" role="tabpanel" aria-labelledby="todo-section">
            <div class="add-items d-flex px-3 mb-0">
              <form class="form w-100">

              
                <div class="form-group d-flex">
                  <input type="text" class="form-control todo-list-input" placeholder="Add To-do">
                  <button type="submit" class="add btn btn-primary todo-list-add-btn" id="add-task">Add</button>
                </div>
              </form>
            </div>
            <div class="list-wrapper px-3">
              <ul class="d-flex flex-column-reverse todo-list">
                <li>
                  <div class="form-check">
                    <label class="form-check-label">
                      <input class="checkbox" type="checkbox">
                      Team review meeting at 3.00 PM
                    </label>
                  </div>
                  <i class="remove ti-close"></i>
                </li>
                <li>
                  <div class="form-check">
                    <label class="form-check-label">
                      <input class="checkbox" type="checkbox">
                      Prepare for presentation
                    </label>
                  </div>
                  <i class="remove ti-close"></i>
                </li>
                <li>
                  <div class="form-check">
                    <label class="form-check-label">
                      <input class="checkbox" type="checkbox">
                      Resolve all the low priority tickets due today
                    </label>
                  </div>
                  <i class="remove ti-close"></i>
                </li>
                <li class="completed">
                  <div class="form-check">
                    <label class="form-check-label">
                      <input class="checkbox" type="checkbox" checked>
                      Schedule meeting for next week
                    </label>
                  </div>
                  <i class="remove ti-close"></i>
                </li>
                <li class="completed">
                  <div class="form-check">
                    <label class="form-check-label">
                      <input class="checkbox" type="checkbox" checked>
                      Project review
                    </label>
                  </div>
                  <i class="remove ti-close"></i>
                </li>
              </ul>
            </div>
            
            
                <small class="text-muted my-auto">47 min</small>
              </li>
            </ul>
          </div>
          <!-- chat tab ends -->
        </div>
      </div>
      <!-- partial -->
      <!-- partial:../../partials/_sidebar.html -->
    
    <?php
include('sidebar.php');
    ?>
      <!-- partial -->
      <div class="main-panel">        
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-9 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Order information table</h4>
                  <p class="card-description">
                  </p>
                  <form class="forms-sample" method="post" action="edit_order.php">
                  <input type="hidden" name="id" id="id" value="<?php echo $id ?>">
                  <div class="form-group">
                      <label for="exampleInputUsername1">Customer</label>
                      <select class="form-control" id="customer" name="customer" placeholder="manufacturer" required>
                      <?php 
                          foreach($customers as $customer){
                            ?>
                            <option <?php if($order['customer'] == $customer['_id']){ ?> selected <?php } ?>value="<?php echo $customer['_id'] ?>"><?php echo $customer['firstName'].' '.$customer['surname'] ?></option>
                        <?php
                          }
                        ?>  
                      </select>
                    </div>
                    <div class="form-group">
                      <label for="exampleInputEmail1">Item
                      </label>
                      <?php
                      foreach($order['items'] as $alreadyitems){
                      ?>
                      <select type="text" class="form-control" id="items" name="items[]" placeholder="model" required>
                         <?php 
                          foreach($items as $item){
                            ?>
                            <option <?php if($alreadyitems == $item['_id']){ ?> selected <?php } ?> value="<?php echo $item['_id'] ?>"><?php echo $item['model'] ?></option>
                        <?php
                          }
                        ?>   
                      
                      </select>
                      <?php } ?>
                      
                    </div>
                    <div class="field_wrapper"></div>
                      <button type="button" class="add_button btn btn-outline-success" onclick="add_items()">Add More</button>

                    <!-- <div class="form-check form-check-flat form-check-primary">
                      <label class="form-check-label">
                        <input type="checkbox" class="form-check-input">
                        Remember me
                      </label>
                    </div> -->
                    <button type="submit" class="btn btn-primary me-2" name="update">Update</button>
                    <button class="btn btn-light">Cancel</button>
                  </form>
                </div>
              </div>
            </div>
            
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
       
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>

  <script>
    $(document).ready(function() {
  var addButton = $('.add_button'); //Add button selector
  var wrapper = $('.field_wrapper'); //Input field wrapper
  //Once add button is clicked
  $(addButton).click(function() {
    //Load options using AJAX
    $.ajax({
      url: 'load_items.php',
      type: 'GET',
      dataType: 'html',
      success: function(response) {
        //Add new input field with loaded options
        var fieldHTML = '<div><br><select class="form-control" id="items" name="items[]" placeholder="model" required>' + response + '</select><br><button type="button" class="remove_button btn btn-outline-danger">Remove</button></div>';
        $(wrapper).append(fieldHTML);
      }
    });
  });
  
  //Once remove button is clicked
  $(wrapper).on('click', '.remove_button', function(e) {
    e.preventDefault();
    $(this).parent('div').remove(); //Remove field html
  });
});

  </script>
</body>

</html>
