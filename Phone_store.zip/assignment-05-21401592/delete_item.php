<?php


require_once 'vendor/autoload.php';
// use App\Models\Customer;
use App\Models\MongoDB;


$id = $_POST['id'];
$connection = new MongoDB;


$check = $connection->deleteitem($id);

if($check == 1){
    $message = "Item deleted successfully";
}else{
    $message = "Failed to delete item";
}
echo "<script>alert('.$message.');</script>";
header("Refresh: 2; url=item_data.php");


?>