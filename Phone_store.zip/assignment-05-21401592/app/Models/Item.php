<?php

namespace App\Models;

// require_once 'vendor/autoload.php';
class Item
{
    private $manufacturer;
    private $model;
    private $price;

    public function __construct($manufacturer,$model,$price)
    {
        $this->manufacturer = $manufacturer;
        $this->model = $model;
        $this->price = $price;
    }

    public function getManufacturer(){
        return $this->manufacturer;
    }

    public function getModel(){
        return $this->model;
    }

    public function getPrice(){
        return $this->price;
    }
}