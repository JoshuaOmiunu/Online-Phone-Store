<nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="customer_data.php">
              <span class="menu-title">Customer Data</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="item_data.php">
              <span class="menu-title">Item Data</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="order_data.php">
              <span class="menu-title">Order Data</span>
            </a>
          </li>          
        </ul>
      </nav>

      
