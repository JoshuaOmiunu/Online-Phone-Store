<?php


require_once 'vendor/autoload.php';
// use App\Models\Customer;
use App\Models\MongoDB;


$id = $_POST['id'];
$connection = new MongoDB;


$check = $connection->deletecustomer($id);

if($check == 1){
    $message = "Customer deleted successfully";
}else{
    $message = "Failed to delete customer";
}
echo "<script>alert('.$message.');</script>";
header("Refresh: 2; url=customer_data.php");


?>