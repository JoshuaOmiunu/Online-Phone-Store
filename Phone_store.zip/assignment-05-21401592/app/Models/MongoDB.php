<?php



namespace App\Models;

require_once 'vendor/autoload.php';
use App\Models\Customer;
use MongoDB\BSON\ObjectID;

class MongoDB{
    private $connection;


    public function __construct()
    {
        $this->connection = new \MongoDB\Client("mongodb://localhost:27017");
    }

    public function add_customer(Customer $c){
        $collection = $this->connection->mobile_store->customer;
        $result = $collection->insertOne([
            'title' => $c->getTitle(),
            'firstName' => $c->getFirstName(),
            'surname' => $c->getSurname(),
            'mobile' => $c->getMobile(),
            'email' => $c->getEmail(),
            'homeaddress' => $c->getAddressLine1(),
            'shippingaddress' => $c->getAddressLine2(),
            'town' => $c->getTown(),
            'country' => $c->getCountry(),
            'eircode' => $c->getEircode(),
        ]); 
        return true;
    }

    public function allcustomers(){
        $collection = $this->connection->mobile_store->customer;
        $result = $collection->find();
        return $result;
    }

    public function deletecustomer(String $id){
        $collection = $this->connection->mobile_store->customer;
        $result = $collection->deleteOne(['_id' => new ObjectID($id)]);

        return $result->getDeletedCount();
        // check if the deletion was successful
        // if ($result->getDeletedCount() === 1) {
        //     echo "Document deleted successfully";
        // } else {
        //     echo "Failed to delete document";
        // }
    }

    public function editcustomer(String $id)
    {
        $collection = $this->connection->mobile_store->customer;
        $customer = $collection->findOne(['_id' => new ObjectID($id)]);
        return $customer;
    }

    public function updatecustomer($id, Customer $c){
        $collection = $this->connection->mobile_store->customer;

        $result = $collection->updateOne(
            ['_id' => new ObjectID($id)],
            ['$set' => [
                'title' => $c->getTitle(),
                'firstName' => $c->getFirstName(),
                'surname' => $c->getSurname(),
                'mobile' => $c->getMobile(),
                'email' => $c->getEmail(),
                'homeaddress' => $c->getAddressLine1(),
                'shippingaddress' => $c->getAddressLine2(),
                'town' => $c->getTown(),
                'country' => $c->getCountry(),
                'eircode' => $c->getEircode(),
                ]]
        );
        return $result->getModifiedCount();
        // if ($result->getModifiedCount() > 0) {
        //     // document updated successfully
        //     echo 'Document updated';
        // } else {
        //     // no documents updated
        //     echo 'No documents updated';
        // }
    }

    public function add_item(Item $i){
        $collection = $this->connection->mobile_store->item;
        $result = $collection->insertOne([
            'manufacturer' => $i->getManufacturer(),
            'model' => $i->getModel(),
            'price' => $i->getPrice(),
        ]); 
        return true;
    }

    public function allitems(){
        $collection = $this->connection->mobile_store->item;
        $result = $collection->find();
        return $result;
    }

    public function deleteitem(String $id){
        $collection = $this->connection->mobile_store->item;
        $result = $collection->deleteOne(['_id' => new ObjectID($id)]);

        return $result->getDeletedCount();
    }

    public function edititem(String $id){
        $collection = $this->connection->mobile_store->item;
        $item = $collection->findOne(['_id' => new ObjectID($id)]);
        return $item;
    }

    public function updateitem($id, Item $i){
        $collection = $this->connection->mobile_store->item;

        $result = $collection->updateOne(
            ['_id' => new ObjectID($id)],
            ['$set' => [
                'manufacturer' => $i->getManufacturer(),
                'model' => $i->getModel(),
                'price' => $i->getPrice(),
                ]]
        );
        return $result->getModifiedCount();
    }


    public function add_order(Order $o){
        $collection = $this->connection->mobile_store->order;
        $result = $collection->insertOne([
            'customer' => $o->getCustomer(),
            'items' => $o->getItems(),
        ]); 
        return true;
    }

    public function allorders(){
        $collection = $this->connection->mobile_store->order;
        $result = $collection->find();
        return $result;
    }

    public function deleteorder(String $id){
        $collection = $this->connection->mobile_store->order;
        $result = $collection->deleteOne(['_id' => new ObjectID($id)]);

        return $result->getDeletedCount();
    }

    public function editorder(String $id){
        $collection = $this->connection->mobile_store->order;
        $order = $collection->findOne(['_id' => new ObjectID($id)]);
        return $order;
    }

    public function updateorder($id, Order $o){
        $collection = $this->connection->mobile_store->order;

        $result = $collection->updateOne(
            ['_id' => new ObjectID($id)],
            ['$set' => [
                'customer' => $o->getCustomer(),
                'items' => $o->getItems(),
                ]]
        );
        return $result->getModifiedCount();
    }
}