<?php
require_once 'vendor/autoload.php';

use App\Models\MongoDB;

$connection = new MongoDB;
$i = $connection->allitems();

$options = '';
foreach($i as $it){
  $options .= '<option value="' . $it['_id'] . '">' . $it['model'] . '</option>';
}

echo $options;
?>